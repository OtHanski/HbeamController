import re
import PARSER.command_functions as command_functions
from .PROCESSING.FileHandler import ChooseSingleFile, ReadJson, ReadTXT

def EXECCOMMAND(settings, instr, command, argument):
    # If command is "null", skip processing
    if command == "NULL":
        return settings
    
    # Fetch the function from the list of functions
    func = getattr(command_functions,command)
    
    # Handle special functions:
    if command == "TESTINPUT":
        None
    elif command[:3] == "FOR":
        print("For loops are only available for scripts")
    elif command == "SCRIPT":
        RUNSCRIPT(argument)
    
    else:
        # If no special cases detected
        temp_settings = func(settings, instr, argument)
    
    # If the function returns a set of settings, overwrite current ones
    if temp_settings != None:
        settings = temp_settings
    
    return settings

def PARSECOMMAND(settings, instr, input,commandlist):
    # Parses a single line command
    
    # Remove extra whitespaces, semicolons, uppercase everything for easier matching
    command = input.strip("\n\t ;").upper()
    
    # If it exists, find argument and remove it from command string
    argindex = command.find(" ")
    if argindex != -1:
        argument = command[argindex+1:]
        command = command[:argindex]
    else:
        argument = ""
    
    if command == "SCRIPT":
        RUNSCRIPT(settings, instr, argument)
        return "NULL", None
    
    # Fetch the function to call from the commandlist dictionary
    keylist = command.split(":")  
    function_call = commandlist
    
    for key in keylist:
        # If "CHAN" command, figure out the channel
        if key[:4] == "CHAN":
            chan = key[4]
            argument = [chan,argument]
            key = "CHAN<n>"
        try:
            function_call = function_call[key]
        except KeyError:
            print("Invalid function request")
            return "NULL", None
    function_call = function_call["function"]
    
    return function_call, argument


def RUNSCRIPT(settings, instr, argument):
    # Argument: filename
    filename = argument

    # Fetch commandlist from file
    commandlist = ReadJson("./PARSER/commands.json")
    
    if filename == "":
        filename = ChooseSingleFile("./Saved_Scripts")
        print("Running script: "+filename[filename.rfind("/")+1:filename.rfind(".")])
        
    if filename == "":
        print("No file selected")
        return None
    
    try: 
        script_string = ReadTXT(filename)
    except FileNotFoundError:
        print("No such script file found")
        return None
        
    commands = re.split(r";|\n",script_string)
    for com in commands:
        if len(com) > 0:
            print(com)
            command, argument = PARSECOMMAND(settings, instr, com.strip(), commandlist)
            EXECCOMMAND(settings, instr, command, argument)
    
    