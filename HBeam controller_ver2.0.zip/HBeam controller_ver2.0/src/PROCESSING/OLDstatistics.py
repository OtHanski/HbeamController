import numpy as np
import integrals as inte
from FileHandler import ChooseFiles
from IntegrationLimits import GetLimits

def ReadData(filename):
    f = open(filename, "r")
    lines = f.readlines()
    data = [[],[]]
    for i in range(1,len(lines)):
        data[1].append(float(lines[i].split()[1]))
        data[0].append(float(lines[i].split()[0]))
    return data

def WriteData(filepath,results):
    f = open(filepath,"w")
    t = results[0]
    V = results[1]
    Vdev = results[2]
    Int = results[3]
    Intdev = results[4]
    
    writestr = "#t [s]\t\tV [V]\t\tVdev [V]\n#SigInt: "+str(Int)+"\n#Intdev: "+str(Intdev)
    for i in range(len(t)):
        writestr += "\n"+str(t[i])+"\t"+str(V[i])+"\t"+str(Vdev[i])
    
    f.write(writestr)

def averaging(files):
    results = [[],[],[],0,0]
    
    # avg
    N = 0
    for fil in files:
        data = ReadData(fil)
        if N == 0:
            results[0] = data[0]
            results[1] = data[1]
        else:
            for i in range(len(data[0])):
                results[1][i] += data[1][i]
        N+=1
    
    for i in range(len(results[1])):
        results[1][i] /= N
    
    # dev
    N = 0
    for fil in files:
        data = ReadData(fil)
        if N == 0:
            results[2] = data[1]
            for i in range(len(data[0])):
                results[2][i] = (results[1][i]-data[1][i])**2
        else:
            for i in range(len(data[0])):
                results[2][i] += (results[1][i]-data[1][i])**2
        N+=1
        
    for i in range(len(results[2])):
        results[2][i] = (results[2][i]/N)**(1/2)
    
    return results

def integrate(results,files, intLimits, offset):
    
    # Find list of indices where time is within our integration limits
    int_indices = [i for i in range(len(results[0])) \
                    if results[0][i] >= intLimits[0] and results[0][i] <= intLimits[1]]
    print(str(int_indices[0])+"  "+str(int_indices[-1]))
    
    time = results[0][int_indices[0]:int_indices[-1]]
    avgVolt = results[1][int_indices[0]:int_indices[-1]]
    for V in avgVolt:
        V -= offset
    
    # int
    results[3] = np.trapz(avgVolt,time)
    
    # intdev
    N = 0
    for fil in files:
        data = ReadData(fil)
        Volt = data[1][int_indices[0]:int_indices[-1]]
        for V in Volt:
            V -= offset
        
        gral = np.trapz(Volt,time)
        results[4] += (results[3]-gral)**2
        N += 1
    
    results[4] = (results[4]/N)**(1/2)
    
    return results
    
    
def main():
    files = ChooseFiles()
    
    # [[t],[avgV],[Vdev],int,intdev]
    results = averaging(files)
    intLimits, offset = GetLimits(np.array([results[0],results[1]]))
    results = integrate(results,files,intLimits,offset)
    
    foldername = files[0][:files[0].rfind("/")]+"/processed/"
    filepath = foldername+files[0][files[0].rfind("/")+1:-4]+"stats.txt"
    
    WriteData(filepath,results)


if __name__ == "__main__":
    main()