import json
import tkinter as tk
from tkinter import filedialog

def ChooseFolder():
    # Initialise tkinter window
    root = tk.Tk()
    root.withdraw()
    
    # Prompt to choose the files to process.
    datafolder = filedialog.askdirectory(initialdir = "..")
    
    return datafolder

def ChooseFiles():
    # Initialise tkinter window
    root = tk.Tk()
    root.withdraw()
    
    # Prompt to choose the files to process.
    files = filedialog.askopenfilenames(initialdir = "..")
    
    # Return filenames as simple list
    return files

def WriteJson(filepath, dict):
    # Writes a dictionary to a json file
    return None

def ReadJson(filepath):
    # Reads a json file, returns the dictionary form of the file
    return None