import numpy as np
import integrals as inte
from FileHandler import ChooseFiles
from IntegrationLimits import GetLimits

def ReadData(filename):
    f = open(filename, "r")
    lines = f.readlines()
    data = [[],[]]
    for i in range(1,len(lines)):
        data[1].append(float(lines[i].split()[1]))
        data[0].append(float(lines[i].split()[0]))
    print(filename)
    return data

def WriteData(filepath,data):
    f = open(filepath,"w")
    t = data["time"]["data"]
    V = data["Channels"]["CH1"]["avg"]
    Vdev = data["Channels"]["CH1"]["stdev"]
    Int = data["Channels"]["CH1"]["Integral"]
    Intdev = data["Channels"][SigChan]["Integraldev"]
    
    writestr = "\#t [s]\t\tV [V]\t\tVdev [V]\t\tIntegral\t\tIntdev"
    for i in range(len(t)):
        writestr += "\n"+str(t[i])+"\t"+str(V[i])+"\t"+str(Vdev[i])
        if i == 0:
            writestr+= "\t"+str(Int)+"\t"+str(Intdev)
    
    f.write(writestr)
    

def initstats():
    # Initialise statistics dictionary
    global stats
    stats = { \
    "time": {"data": [],"unit": "s"}, \
    "Channels": {"CH1":{"avg":[], "stdev":[], "unit": "V"}, \
                 "CH2":{"avg":[], "stdev":[], "unit": "V"}, \
                 "CH3":{"avg":[], "stdev":[], "unit": "V"}, \
                 "CH4":{"avg":[], "stdev":[], "unit": "V"}}, \
    "measurement": "" \
    }
    
def sortfiles(files):
    # Use dictionary to figure out which file is part of which measurement
    sorted = {}
    for file in files:
        # Read from metadata which measurement series each file is a part of
        measurement = ReadData(file)["measurement"]
        # Try adding file to corresponding measurement key, create key if not existing
        try:
            sorted[measurement].append(file)
        except KeyError:
            sorted[measurement] = [file]
    
    return sorted

    
def averaging(filelist):
    # Due to vast amount of data, can't really be done by passing the data directly
    # Additionally, we can't keep the data in memory for processing, so will need to
    # read the datafiles multiple times for the processing.
    
    global stats
    
    # Initialise averaging
    data = np.array(ReadData(filelist[0]))
    results = [data
    len_data = len(data[0])
    N = 0
    
    # On first pass we average
    for file in filelist:
        data = ReadData(file)
        if stats["Channels"]["CH1"]["avg"] == []:
            stats["Channels"]["CH1"]["avg"] = data["Channels"]["CH1"]["data"]
        else:
            stats["Channels"]["CH1"]["avg"] += data["Channels"]["CH1"]["data"]
        N += 1
    
    # Then divide to get the average and set the units
    for Channel in stats["Channels"]:
        stats["Channels"][Channel]["avg"] /= N
    
    # On second pass we calculate deviation.
    for file in filelist:
        data = ReadData(file)
        for Channel in data["Channels"]:
            # Sum squared deviation from mean
            stats["Channels"][Channel]["stdev"] += \
                (data["Channels"][Channel]["data"]-stats["Channels"][Channel]["avg"])**2
    
    # Then divide by N and take sqrt to get standard deviation
    for Channel in stats["Channels"]:
        stats["Channels"][Channel]["stdev"] = (stats["Channels"][Channel]["stdev"]/N)**(1/2)
    
    
def Integrate(intLimits, offset, SigChan, meas_files):
    
    time = np.array(stats["time"]["data"])
    avgVoltages = np.array(stats["Channels"][SigChan]["avg"])
    
    # Find list of indices where time is within our integration limits
    int_indices = [i for i in range(len(time)) \
                    if time[i] >= intLimits[0] and time[i] <= intLimits[1]]
    
    # Limit integral to within the integration limtis
    time = time[int_indices]
    avgVoltages[int_indices]
    
    # Calculate integral
    avgIntegral = np.trapz(avgVoltages, time)
    stats["Channels"][SigChan]["Integral"] = avgIntegral
    stats["Channels"][SigChan]["Integraldev"] = 0
    
    # To get statistics of integral, we need to again read through the files
    Voltages = np.zeros(1)
    N = 0
    for file in meas_files:
        N+=1
        data = ReadData(file)
        # Fetch the voltages matching our timewindow
        Voltages = np.array(data["Channels"][SigChan]["data"])[int_indices]
        integral = np.trapz(Voltages, time)
        # Sum squared deviation from mean
        stats["Channels"][SigChan]["Integraldev"] += (integral-avgIntegral)**2
    
    # Then divide by N and take sqrt to get standard deviation
    for Channel in stats["Channels"]:
        stats["Channels"][SigChan]["Integraldev"] = (stats["Channels"][SigChan]["Integraldev"]/N)**(1/2)
    
    
def AskSignalChannel():
    # Ask user which channel data is expected to have the signal
    User_in = input("Please enter the number of the channel holding\nthe signal data, or enter \"quit\" to quit: ")
    if User_in.strip() == "quit":
        return User_in
    try:
        Chan = "CH"+str(int(User_in))
        return Chan
    except ValueError:
        print("Invalid input, please enter an integer number.\n")
        
    
def get_stats():
    # This is the "main" routine
    
    # First initialise our statistics dictionary,
    stats = {}
    initstats()
    
    # Next let's fetch our files. Do one measurement at a time please.
    files_sorted = ChooseFiles()
    
    # Define the datafolder to save processed files in
    for measurement in files_sorted:
        foldername = files_sorted[0]
        break
    # Fetch the folder used for the chosen files, put the processed files in a subfolder
    foldername = foldername[:foldername.rfind("/")]+"/processed/"
    
    # Ask user for the signal channel for integration
    SigChan = "CH1"
    
    # Controls whether integration limits are asked for each measurement
    while True:
        User_in = input("Use the same integration limits for all measurements? y/n/quit:\n")
        if User_in == "y":
            testwfdat = ReadData(files_sorted[0])
            testwf = np.array([testwfdat["time"]["data"],testwfdat["Channels"]["CH1"]["data"]])
            print(testwf)
            intLimits, offset = GetLimits(testwf)
            ask_Limits = False
            break
        elif User_in == "n":
            ask_Limits = True
            break
        elif User_in.strip() == "quit":
            return User_in
        else:
            print("Invalid input. Please enter a valid input (y/n/quit)")

    # In each loop we process and save the data for one measurement set
    stats["measurement"] = measurement
    averaging(files_sorted)
    # The saved stats files are named after the measurements
    filepath = measurement[:-4]+".txt"
    
    if ask_Limits:
        intLimits, offset = GetLimits()
    Integrate(intLimits, offset, "CH1", files_sorted)
    WriteData(filepath,stats)

if __name__ == "__main__":
    get_stats()