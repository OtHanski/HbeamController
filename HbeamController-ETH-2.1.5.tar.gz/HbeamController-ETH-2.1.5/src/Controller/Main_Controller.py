import time
from PARSER.parser import PARSECOMMAND, EXECCOMMAND
from PARSER.PROCESSING import FileHandler as FH
from PARSER.RTM_CONTROLS import RTMINIT
from PARSER.TRUEFORM_CONTROLS import TRUEFORMINIT
from PARSER.SYSTEM_COMMANDS import SYSEXIT


def INIT(settings):
    instr = {}
    
    argument = None
    
    devices_initialized = False
    
    if settings["RTM"]["STAT"] == "ON":
        settings, RTMinstr = RTMINIT(settings)
        instr["RTM3004"] = RTMinstr
        devices_initialized = True
    
    if settings["TRUEFORM"]["STAT"] == "ON":
        settings,TRUEFORMinstr = TRUEFORMINIT(settings)
        instr["TRUEFORM"] = TRUEFORMinstr
        devices_initialized = True
    
    if devices_initialized:
        print("Initializing",end='', flush=True)
        for rep in range(12):
            time.sleep(0.5)
            print('.', end='', flush=True)
        print('', end='\n', flush=True)
    
    devicestr = "Devices connected:"
    for key in instr:
        devicestr += "\n├ "+key
    print("\n"+devicestr+"\n")
    
    return settings, instr


def main_Controller():
    # Main controller routine set inside a loop. 
    
    # Initializing the system settings
    try:
        print("Initializing default settings")
        commandlist = FH.ReadJson("./PARSER/commands.json")
        settings = FH.ReadJson("./SETTINGS/DEFAULT.json")
        settings, instr = INIT(settings)
    except Exception as initexname:
        print("Program ran into the following error during initialization:\n"+exname)
        print("Exiting program")
        SYSEXIT(settings,instr,"")
    
    # Start controller loop
    print("Controller online, you may enter your commands:")
    while True:
        try:
            # Ask the user for input
            User_in = input(">>>")
            # Parse the input
            command, argument = PARSECOMMAND(settings, instr, User_in,commandlist)
            # Execute parsed command
            if not [command, argument] == [None, None]:
                settings, instr = EXECCOMMAND(settings,instr,command,argument)
            if command in ["LOAD_SETTINGS"]:
                settings, instr = INIT(settings)
        except Exception as exname:
            print("Program ran into the following error:\n"+exname)
            Exception_input = input("To shut down program, enter \"quit\", otherwise press Enter to proceed.")
            if Exception_input.lower() == "quit":
                SYSEXIT(settings,instr,"")
            


if __name__ == "__main__":
    main_Controller()