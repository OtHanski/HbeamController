import PARSER.command_functions as command_functions
from .PROCESSING.FileHandler import ChooseFiles, ReadTXT

def EXECCOMMAND(settings, instr, command, argument):
    # Fetch the function from the list of functions
    func = getattr(command_functions,command)
    
    # Handle special functions:
    if command == "TESTINPUT":
        None
    
    else:
        # If no special cases detected
        temp_settings = func(settings, instr, argument)
    
    # If the function returns a set of settings, overwrite current ones
    if temp_settings != None:
        settings = temp_settings
    
    return settings

def PARSECOMMAND(input,commandlist):
    # Parses a single line command
    
    # Remove extra whitespaces, semicolons, uppercase everything for easier matching
    command = input.strip("\n\t ;").upper()
    
    # If it exists, find argument and remove it from command string
    argindex = command.find(" ")
    if argindex != -1:
        argument = command[argindex+1:]
        command = command[:argindex]
    else:
        argument = ""
    
    # Fetch the function to call from the commandlist dictionary
    keylist = command.split(":")  
    function_call = commandlist
    
    for key in keylist:
        # If "CHAN" command, figure out the channel
        if key[:4] == "CHAN":
            chan = key[4]
            argument = [chan,argument]
            key = "CHAN<n>"
        try:
            function_call = function_call[key]
        except KeyError:
            print("Invalid function request")
            return None, None
    function_call = function_call["function"]
    
    return function_call, argument

def RUNSCRIPT(commandlist,filename = "./Saved_Scripts"):
    
    if filename == "./Saved_Scripts":
        filename = ChooseFiles()
    
    script_string = ReadTXT(filename)
    commands = script_string.split(";")
    for com in commands:
        command, argument = PARSECOMMAND(com.strip(), commandlist)
        EXECCOMMAND(command, argument)
    
    