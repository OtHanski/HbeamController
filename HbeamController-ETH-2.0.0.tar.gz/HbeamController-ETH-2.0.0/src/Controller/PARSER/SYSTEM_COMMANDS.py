import sys

def SYSEXIT(settings, instr, argument):
    # Argument: None
    if settings["RTM"]["STAT"] == "ON":
        instr["RTM3004"].close()
    if settings["Trueform"]["Stat"] == "ON":
        instr["Trueform"].close()
    
    if settings["ERROR"] != "":
        print("System has encountered an error:\n"+settings["ERROR"])
        sys.exit("Quitting program")
    else:
        sys.exit("System has exited succesfully")
    
    