import sys

def SYSEXIT(settings, instr, argument):
    # Argument: None
    if settings["RTM"]["STAT"] == "ON":
        instr["RTM3004"].close()
    if settings["TRUEFORM"]["STAT"] == "ON":
        instr["Trueform"].close()
    
    if settings["ERROR"] != "":
        print("System has encountered an error:\n"+settings["ERROR"])
        sys.exit("Quitting program")
    else:
        sys.exit("System has exited succesfully")
    
def SETMEASFILENAME(settings,instr,argument):
    filepath = argument
    
    measfolder = filepath[:filepath.rfind("/")]
    filename = filepath[filepath.rfind("/")+1:filepath.rfind(".")]
    
    settings["FILE"]["FILENAME"] = filename
    settings["FILE"]["MEASFOLDER"] = measfolder
    
    return settings

def SETMEASUREMENT(settings,instr,argument):
    measurement = argument
    
    settings["FILE"]["MEASUREMENT"] = measurement
    return settings