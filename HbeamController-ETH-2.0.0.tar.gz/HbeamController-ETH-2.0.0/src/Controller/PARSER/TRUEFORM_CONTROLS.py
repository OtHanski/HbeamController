def RTMVISA(settings):
    # Find the USB address the RTM3004 is plugged into.
    # Note, at the moment the program is written specifically for USB.
    
    ResList=rm.list_resources()
    ID =""
    
    for ResID in ResList:
        if ResID[0:3] == "USB" and ResID[-5:] == "INSTR":
            instr = rm.open_resource(ResID)
            # Ping the device for ID, check if it's the RTM
            ID = instr.query("*IDN?")
            if ID == 'Rohde&Schwarz,RTM3004,1335.8794k04/103028,01.550\n':
                settings["RTM"]["VISAID"] = ID
    
    return settings

def RTMWRITESCPI(SCPI_string, instr):
    instr.write(SCPI_string)
    
def RTMREADSCPI(instr):
    read_data = instr.read()
    print(str(read_data))
    return read_data

def RTMQUERYSCPI(SCPI_string, instr):
    read_data = instr.query(SCPI_string)
    print(read_data)
    return read_data
    