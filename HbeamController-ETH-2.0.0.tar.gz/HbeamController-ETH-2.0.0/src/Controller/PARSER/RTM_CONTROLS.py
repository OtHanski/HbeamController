from datetime import date
import pyvisa as visa
import numpy as np
from .PROCESSING.FileHandler import WriteJson, CheckFolder



def RTMVISA(settings):
    # Find the USB address the RTM3004 is plugged into.
    # Note, at the moment the program is written specifically for USB.
    
    rm = visa.ResourceManager()
    ResList=rm.list_resources()
    ID =""
    
    for ResID in ResList:
        if ResID[0:3] == "USB" and ResID[-5:] == "INSTR":
            instr = rm.open_resource(ResID)
            # Ping the device for ID, check if it's the RTM
            ID = instr.query("*IDN?")
            if ID == 'Rohde&Schwarz,RTM3004,1335.8794k04/103028,01.550\n':
                settings["RTM"]["VISAID"] = ID
    
    return settings

# Define the direct SCPI communication functions
def RTMWRITESCPI(SCPI_string, instr):
    instr.write(SCPI_string)
    
def RTMREADSCPI(instr):
    read_data = instr.read()
    print(str(read_data))
    return read_data

def RTMQUERYSCPI(SCPI_string, instr):
    read_data = instr.query(SCPI_string)
    print(read_data)
    return read_data

# Direct setting commands
def RTMCHANSTAT(arguments,instr):
    # arguments: [channel, status]
    
    allowed_args = ("ON","OFF")
    if arguments[1] in allowed_args:
        # build command
        SCPI_string = "CHAN"+str(arguments[0])+":STAT "+arguments[1]
        RTMWRITESCPI(SCPI_string,instr)
    else:
        print("Invalid command argument")
    
def RTMCHANOFFSET(arguments,instr):
    # arguments: [channel, offset]
    
    allowed_channels = ["1","2","3","4"]
    
    # Check whether arguments correct
    correct_arg = False
    try:
        float(arguments[1])
        if arguments[0] in allowed_channels:
            correct_arg = True
    except ValueError:
        print("Invalid command argument")
    
    if correct_arg:
        # build command
        SCPI_string = "CHAN"+str(arguments[0])+":OFFS "+arguments[1]
        RTMWRITESCPI(SCPI_string,instr)

def RTMCHANSCALE(arguments,instr):
    # arguments: [channel, scale]
    
    allowed_channels = ["1","2","3","4"]
       
    # Check whether arguments correct
    correct_arg = False
    try:
        float(arguments[1])
        if arguments[0] in allowed_channels:
            correct_arg = True
    except ValueError:
        print("Invalid command argument")
    
    if correct_arg:
        # build command
        SCPI_string = "CHAN"+str(arguments[0])+":SCAL "+arguments[1]
        RTMWRITESCPI(SCPI_string,instr)
    
def RTMTIMEOFFSET(argument,instr):
    # argument: offset

    correct_arg = False
    try:
        float(arguments)
        correct_arg = True
    except ValueError:
        print("Invalid command argument")

    if correct_arg:
        # build command
        SCPI_string = "TIM:POS "+argument
        RTMWRITESCPI(SCPI_string,instr)

def RTMTIMESCALE(argument,instr):
    # argument: scale
    
    correct_arg = False
    try:
        float(argument)
        correct_arg = True
    except ValueError:
        print("Invalid command argument")    
    
    if correct_arg:
        # build command
        SCPI_string = "TIM:SCAL "+argument
        RTMWRITESCPI(SCPI_string,instr)
    else:
        print("Invalid command argument")

def RTMDATAPOINTS(argument,instr):
    # argument: n_points
    
    correct_arg = False
    try:
        int(argument)
        correct_arg = True
    except ValueError:
        print("Invalid command argument")
        
    if correct_arg:
        # build command
        SCPI_string = "ACQ:POIN "+argument
        RTMWRITESCPI(SCPI_string,instr)

def RTMTRIGSOURCE(argument,instr):
    # argument: source channel
        
    correct_arg = False
    try:
        int(argument)
        correct_arg = True
    except ValueError:
        print("Invalid command argument")
    
    if correct_arg:
        # build command
        SCPI_string = "TRIG:A:SOUR "+argument
        RTMWRITESCPI(SCPI_string,instr)

def RTMTRIGMODE(argument,settings,instr):
    # argument: trigger mode
    
    allowed_args = ["AUTO", "NORM"]
    correct_arg = False
    try:
        if argument in allowed_args:
            correct_arg = True
    except ValueError:
        print("Invalid command argument")
    
    if correct_arg:
        # build command
        SCPI_string = "TRIG:A:MODE "+argument
        RTMWRITESCPI(SCPI_string,instr)

def RTMTRIGLEVEL(argument,settings,instr):
    # argument: trigger mode

    correct_arg = False
    try:
        float(argument)
        correct_arg = True
    except ValueError:
        print("Invalid command argument")
    
    if correct_arg:
        # build command
        SCPI_string = "TRIG:A:LEV "+argument
        RTMWRITESCPI(SCPI_string,instr)
        

# Main measurement routine
def RTMMEASURE(nWaveforms,settings,instr):
    rootfolder = settings["FILE"]["ROOTFOLDER"]
    measfolder = "/"+settings["FILE"]["MEASFOLDER"]
    
    # Set up measurement folder by date
    date = date.today()
    datestring = date.strftime("%Y-%m-%d")
    measfolder =  datestring + measfolder
    
    folder = rootfolder +"/"+ measfolder
    # Create folder
    CheckFolder(folder)
    
    # Setup measurement dictionary
    data = {                                                                        \
            "metadata": {                                                           \
                "measurement": settings["FILE"]["MEASUREMENT"],                     \
                "N": nWaveforms,                                                    \
                "Trigger channel": settings["RTM"]["TRIG_SETTINGS"]["SOUR"],        \
                "STAT": [settings["CHAN1"]["STAT"], settings["CHAN2"]["STAT"],      \
                         settings["CHAN3"]["STAT"], settings["CHAN4"]["STAT"]],     \
                "header": [],                                                       \
                "filetype": "measurement"                                           \
                        },                                                          \
            "time": {                                                               \
                "unit": "s",                                                        \
                "data": []                                                          \
                    },                                                              \
            "Channels": {                                                           \
                    "CH1":  {                                                       \
                        "unit": "V",                                                \
                        "Voltage": []                                               \
                            },                                                      \
                    "CH2":  {                                                       \
                        "unit": "V",                                                \
                        "Voltage": []                                               \
                            },                                                      \
                    "CH3":  {                                                       \
                        "unit": "V",                                                \
                        "Voltage": []                                               \
                            },                                                      \
                    "CH4":  {                                                       \
                        "unit": "V",                                                \
                        "Voltage": []                                               \
                            }                                                       \
                        }                                                           \
            }
    
    for i in range(nWaveforms):
        # Build filepath according to settings, index by measurement number
        filename = settings["FILE"]["FILENAME"]+"_"+str(i+1).zfill(len(str(nWaveforms)))+".json"
        filepath = folder+"/"+filename
        data = RTMGETWAVEFORM(data,settings,instr)
        WriteJson(filepath,data)
        if (i+1)%10 == 0:
            print("Waveform number "+str(i+1)+" done")


def RTMGETHEADER(Channel,data,instr):
    # Fetches the data file header from RTM3004  
    header = []
    # [t_start, t_stop, n_samples, values per interval]
    headerstring = RTM.query("CHAN:DATA"+str(Channel)+":HEAD?")
    
    # Parse numerical values from the string format header
    sep1 = headerstring.find(",");
    sep2 = headerstring.find(",",sep1+1);
    sep3 = headerstring.find(",",sep2+1);
    header = [float(headerstring[0:sep1]), float(headerstring[sep1+1:sep2]), \
              int(headerstring[sep2+1:sep3]), int(headerstring[sep3+1:])]
              
    # If header is empty, there's a problem reading data from the test channel
    if header[0]==0 and header[1]==0 and header [2]==0 and header[3]==0:
        print("No reference signal detected.")
        ########################################
        #### REWRITE THIS PART, GLOBAL EXIT ####
        ########################################
        Waiter = input("Please connect a signal or enter \"q\" to quit.")
        if Waiter == "q":
            instr.close()
            sys.exit("Program ended by user")
        else:
            print("Retrying", flush=True)
            for rep in range(10):
                time.sleep(0.5)
                print('.', end='', flush=True)
            print('', end='\n', flush=True)
            FetchHeader()
    
    # Write header to metadata
    data["metadata"]["header"] = header
    
    return data,header

# Data decoder for RTM oscilloscope
def RTMDECODEWAVEFORMS(rawdata,header):
    # By default, data is read in binary packed format, this function decodes that into human-readable data.
    # [t_start, t_stop, n_samples, values per interval]
    header
    t_start, t_stop, nSamples = header[0], header[1], header[2]
    dt=(t_stop-t_start)/(nSamples-1)
    
    # Initializing data array
    decWaves = np.zeros((1+len(rawdata),nSamples),'f')
    decWaves[0] = [round((t_start+i*dt)*1e10)/1e10 for i in range(nSamples)]
    
    for ch in range(len(rawdata)):
        # First character should be "#".
        pound = rawdata[ch][0:1]
        if pound != b'#':
            print("ERROR: Unknown data format returned from scope!")
            quit()
            
        # Second character is number of following digits for data string length value.
        length_digits = int(rawdata[ch][1:2])
        data_length = int(rawdata[ch][2:length_digits+2])
        
        # from the given data length, and known header length, we get indices:
        data_begin = length_digits + 2  # 2 for the '#' and digit count
        data_end = data_begin + data_length
        data_entries = data_length // 4;
        
        # Check that data length matches up
        if data_entries != nSamples:
            print("ERROR: Data length not consistent with number of sampleFs!")
            quit()
        # Unpack the data
        decWaves[ch+1] = np.float32(struct.unpack('f'*data_entries,rawdata[ch][data_begin:data_end]))
    return list(decWaves)
    
def RTMGETWAVEFORM(data,settings,instr):
    
    # As comparison channel, choose first online channel
    ChanStat = data["metadata"]["STAT"]
    for index in len(range(ChanStat)):
        if ChanStat[index] == "ON":
            ComparisonChannel = index+1
    
    # Get comparison waveform
    Comp_Waveform = data["Channels"]["CH"+str(ComparisonChannel)]["Voltage"]

    while True:
        # Initialize data array
        tempdata=[]
        # Datakey tells which channels were recorded
        datakey=[]
        
        # Read all (active) data channels
        if CHANSTAT[0] == "ON":
            RTM.write("CHAN1:DATA?")
            ch1 = RTM.read_raw()
            tempdata.append(ch1)
            datakey.append("CH1")
        if CHANSTAT[1] == "ON":
            RTM.write("CHAN2:DATA?")
            ch2 = RTM.read_raw()
            tempdata.append(ch2)
            datakey.append("CH2")
        if CHANSTAT[2] == "ON":
            RTM.write("CHAN3:DATA?")
            ch3 = RTM.read_raw()
            tempdata.append(ch3)
            datakey.append("CH3")
        if CHANSTAT[3] == "ON":
            RTM.write("CHAN4:DATA?")
            ch4 = RTM.read_raw()
            tempdata.append(ch4)
            datakey.append("CH4") 
        
        # Read the comparison data
        RTM.write("CHAN"+str(ComparisonChannel)+":DATA?")
        ch_check = RTM.read_raw()
        
        # Check that data has changed from last measurement (Comp_Waveform) 
        # and that oscilloscope didn't refresh mid-measurement (ch_check)
        if (tempdata[ComparisonChannel-1] != Comp_Waveform) and (data[ComparisonChannel-1] == ch_check):
            data, header = RTMGETHEADER(ComparisonChannel,data,instr)
            # Decode the read data
            tempdata = RTMDECODEWAVEFORMS(tempdata,header)
            
            # Write the measured data to the data file
            for index in range(len(datakey)):
                data["Channels"][chan[index]] = tempdata[index]
                
            return data
    
def RTMINIT(settings):
    
    # Fetch visa address
    settings = RTMVISA(settings)
    VISAID = settings["RTM"]["VISAID"]
    
    # Set up device connection
    rm = visa.ResourceManager()
    RTM = rm.open_resource(VISAID)
    
    RTM_SETTINGS = settings["RTM"]
    
    # Reset the device
    RTM.write("*RST")
    
    print("Initializing",end='', flush=True)
    
    # Set initial channel settings
    for chan in RTM_SETTINGS["CHAN_SETTINGS"]:
        for parameter in RTM_SETTINGS["CHAN_SETTINGS"][chan]:
            SCPI_string = chan + parameter+" " + RTM_SETTINGS["CHAN_SETTINGS"][chan][parameter]
            RTMWRITESCPI(SCPI_string,RTM)
    
    # Set initial time settings
    for parameter in RTM_SETTINGS["TIME_SETTINGS"]:
        SCPI_string = "TIM:" + parameter + " " + RTM_SETTINGS["TIME_SETTINGS"][parameter]
        RTMWRITESCPI(SCPI_string,RTM)
    
    # Set trigger settings
    for parameter in RTM_SETTINGS["TRIG_SETTINGS"]:
        SCPI_string = "TRIG:A:" + parameter + " " + RTM_SETTINGS["TRIG_SETTINGS"][parameter]
        RTMWRITESCPI(SCPI_string,RTM)
    
    # Set data acquisition settings 
    for parameter in RTM_SETTINGS["ACQUISITION_SETTINGS"]:
        SCPI_string = "ACQ:" + parameter + " " + RTM_SETTINGS["ACQUISITION_SETTINGS"][parameter]
        RTMWRITESCPI(SCPI_string,RTM)
        
    # Set format settings. Avoid touching, the decoder has been programmed for these.
    for parameter in RTM_SETTINGS["FORMAT_SETTINGS"]:
        SCPI_string = parameter + " " + RTM_SETTINGS["ACQUISITION_SETTINGS"][parameter]
        RTMWRITESCPI(SCPI_string,RTM)
    
    # Wait for a bit for the scope to update
    for rep in range(12):
        time.sleep(0.5)
        print('.', end='', flush=True)
    print('', end='\n', flush=True)

    # Set the device status to "ON", enabling measurement
    settings["RTM"]["STAT"] = "ON"
    
    return settings, RTM
    
    
    
    
    
    
    
    