import numpy as np
from .FileHandler import ReadJson, WriteJson, ChooseFiles
from .IntegrationLimits import GetLimits

def initstats():
    # Initialise statistics dictionary
    global stats
    stats = { \
    "metadata": {
             "measurement": "", \
             "N": 0,  \
             "filetype": "statistics"
             },  \
    "time": {"data": [],"unit": "s"}, \
    "Channels": {  \
                "CH1":{"avg":[], "stdev":[], "unit": "V"}, \
                "CH2":{"avg":[], "stdev":[], "unit": "V"}, \
                "CH3":{"avg":[], "stdev":[], "unit": "V"}, \
                "CH4":{"avg":[], "stdev":[], "unit": "V"}  \
                } \
    }
    
def sortfiles(files):
    # Use dictionary to figure out which file is part of which measurement
    sorted = {}
    for file in files:
        # Read from metadata which measurement series each file is a part of
        measurement = ReadJson(file)["metadata"]["measurement"]
        # Try adding file to corresponding measurement key, create key if not existing
        try:
            sorted[measurement].append(file)
        except KeyError:
            sorted[measurement] = [file]
    
    return sorted

    
def averaging(filelist):
    # Due to vast amount of data, can't really be done by passing the data directly
    # Additionally, we can't keep the data in memory for processing, so will need to
    # read the datafiles multiple times for the processing.
    
    global stats
    
    # Initialise averaging
    data = ReadJson(filelist[0])
    len_data = len(data["time"]["data"])
    stats["time"]["data"] = data["time"]["data"]
    for Channel in stats["Channels"]:
        stats["Channels"][Channel]["avg"] = np.zeros(len_data)
        stats["Channels"][Channel]["stdev"] = np.zeros(len_data)
    N = 0
    
    # On first pass we average
    for file in filelist:
        data = ReadJson(file)
        for Channel in data["Channels"]:
            # First we sum all of the datapoints
            stats["Channels"][Channel]["avg"] += data["Channels"][Channel]["data"]
        N += 1
    
    # Save number of measurements
    stats
    
    # Then divide to get the average and set the units
    for Channel in stats["Channels"]:
        stats["Channels"][Channel]["avg"] /= N
    
    # On second pass we calculate deviation.
    for file in filelist:
        if file[-5:] == ".json":
            data = ReadJson(file)
            for Channel in data["Channels"]:
                # Sum squared deviation from mean
                stats["Channels"][Channel]["stdev"] += \
                    (data["Channels"][Channel]["data"]-stats["Channels"][Channel]["avg"])**2
    
    # Then divide by N and take sqrt to get standard deviation
    for Channel in stats["Channels"]:
        stats["Channels"][Channel]["stdev"] = (stats["Channels"][Channel]["stdev"]/N)**(1/2)
    
    
def Integrate(intLimits, offset, SigChan, meas_files):
    global stats
    
    time = np.array(stats["time"]["data"])
    avgVoltages = np.array(stats["Channels"][SigChan]["avg"])
    n_points = len(time)
    
    # Find list of indices where time is within our integration limits
    int_indices = [i for i in range(len(time)) \
                    if time[i] >= intLimits[0] and time[i] <= intLimits[1]]
    
    # Limit integral to within the integration limtis
    time = time[int_indices]
    avgVoltages = avgVoltages[int_indices]
    n_points = len(time)
    
    # Apply offset
    for i in range(n_points):
        avgVoltages[i] -= offset
    
    # Calculate integral
    avgIntegral = np.trapz(avgVoltages, time)
    stats["Channels"][SigChan]["Integral"] = avgIntegral
    
    # To get statistics of integral, we need to again read through the files
    Voltages = np.zeros(1)
    N = 0
    
    for file in meas_files:
        if file[-5:] == ".json":
            N+=1
            data = ReadJson(file)
            # Fetch the voltages matching our timewindow
            Voltages = np.array(stats["Channels"][SigChan]["data"])[int_indices]
            
            for i in range(n_points):
                Voltages[i] -= offset
            
            # Integral using trapezoidal approximation
            integral = np.trapz(Voltages, time)
            # Sum squared deviation from mean
            stats["Channels"][SigChan]["Integraldev"] += (integral-avgIntegral)**2
    
    # Then divide by N and take sqrt to get standard deviation
    for Channel in stats["Channels"]:
        stats["Channels"][SigChan]["Integraldev"] = (stats["Channels"][SigChan]["Integraldev"]/N)**(1/2)
    
    
    
def AskSignalChannel():
    # Ask user which channel data is expected to have the signal
    User_in = input("Please enter the number of the channel holding\nthe signal data, or enter \"quit\" to quit: ")
    if User_in.strip() == "quit":
        return User_in
    try:
        Chan = "CH"+str(int(User_in))
        return Chan
    except ValueError:
        print("Invalid input, please enter an integer number.\n")
        
    
def get_stats():
    # This is the "main" routine
    
    # First initialise our statistics dictionary,
    stats = {}
    initstats()
    
    # Next let's fetch our files. Files are sorted by "measurement" metadata into a dictionary
    files_sorted = sortfiles(ChooseFiles())
    
    # Define the datafolder to save processed files in
    for measurement in files_sorted:
        foldername = files_sorted[measurement][0]
        break
    # Fetch the folder used for the chosen files, put the processed files in a subfolder
    foldername = foldername[:foldername.rfind("/")]+"/processed/"
    
    # Ask user for the signal channel for integration
    SigChan = AskSignalChannel()
    if SigChan == "quit":
        return SigChan
    
    # Controls whether integration limits are asked for each measurement
    while True:
        User_in = input("Use the same integration limits for all measurements? y/n/quit:\n")
        if User_in == "y":
            intLimits, offset = GetLimits()
            ask_Limits = False
            break
        elif User_in == "n":
            ask_Limits = True
            break
        elif User_in.strip() == "quit":
            return User_in
        else:
            print("Invalid input. Please enter a valid input (y/n/quit)")

    # In each loop we process and save the data for one measurement set
    for measurement in files_sorted:
        stats["measurement"] = measurement
        averaging(files_sorted[measurement])
        # The saved stats files are named after the measurements
        filepath = foldername+measurement+".json"
        
        if ask_Limits:
            intLimits, offset = GetLimits()
        Integrate(intLimits, offset, SigChan, files_sorted[measurement])
        
        WriteJson(filepath,stats)
    
    