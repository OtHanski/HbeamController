from PARSER.parser import PARSECOMMAND, EXECCOMMAND
from PARSER.PROCESSING import FileHandler as FH
from PARSER.RTM_CONTROLS import RTMINIT

def INIT(settings):
    instr = {}
    
    argument = None
    
    if settings["RTM"]["STAT"] == "ON":
        settings, RTMinstr = RTMINIT(settings)
        instr["RTM3004"] = RTMinstr
        print("INIT: "+str(instr))
    
    return settings, instr

def main_Controller():
    # Main controller routine set inside a loop. 
    
    # Initializing the system settings
    print("Initializing default settings")
    commandlist = FH.ReadJson("./PARSER/commands.json")
    settings = FH.ReadJson("./SETTINGS/DEFAULT.json")
    settings, instr = INIT(settings)
    
    # Start controller loop
    print("Controller online, you may enter your commands:")
    while True:
        # Ask the user for input
        User_in = input(">>>")
        # Parse the input
        command, argument = PARSECOMMAND(User_in,commandlist)
        # Execute parsed command
        if not [command, argument] == [None, None]:
            settings = EXECCOMMAND(settings,instr,command,argument)


if __name__ == "__main__":
    main_Controller()