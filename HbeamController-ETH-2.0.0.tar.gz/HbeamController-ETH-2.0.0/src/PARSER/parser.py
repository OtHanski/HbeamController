from FileHandler import ChooseFiles, ReadTXT

def EXECCOMMAND(command, argument, commandlist):
    return None

def PARSECOMMAND(input,commandlist):
    # Parses a single line command
    
    # Remove extra whitespaces, semicolons, uppercase everything for easier matching
    command = input.strip("\n\t ;").upper()
    
    # If it exists, find argument and remove it from command string
    argindex = command.find(" ")
    if argindex != -1:
        argument = command[argindex+1:]
        command = command[:argindex]
    else:
        argument = ""
    
    # Fetch the function to call from the commandlist dictionary
    keylist = command.split(":")  
    function_call = commandlist
    
    for key in keylist:
        # If "CHAN" command, figure out the channel
        if key[:4] == "CHAN":
            chan = key[4]
            argument = [chan,argument]
            key = "CHAN<n>"
        function_call = function_call[key]
    function_call = function_call["function"]
    
    return command, argument

def RUNSCRIPT(filename = "./Saved_Scripts",commandlist)
    
    if filename = "./Saved_Scripts":
        filename = ChooseFiles()
    
    script_string = ReadTXT(filename)
    commands = script_string.split(";")
    for com in commands:
        command, argument = PARSECOMMAND(com.strip(), commandlist)
        EXECCOMMAND(command, argument)
    
    