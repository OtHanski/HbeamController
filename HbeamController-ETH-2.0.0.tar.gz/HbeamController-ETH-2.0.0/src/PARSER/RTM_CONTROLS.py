import date
from FileHandler import WriteJson, CheckFolder



def RTMVISA(settings):
    # Find the USB address the RTM3004 is plugged into.
    # Note, at the moment the program is written specifically for USB.
    
    ResList=rm.list_resources()
    ID =""
    
    for ResID in ResList:
        if ResID[0:3] == "USB" and ResID[-5:] == "INSTR":
            instr = rm.open_resource(ResID)
            # Ping the device for ID, check if it's the RTM
            ID = instr.query("*IDN?")
            if ID == 'Rohde&Schwarz,RTM3004,1335.8794k04/103028,01.550\n':
                settings["RTM"]["VISAID"] = ID
    
    return settings

# Define the direct SCPI communication functions
def RTMWRITESCPI(SCPI_string, instr):
    instr.write(SCPI_string)
    
def RTMREADSCPI(instr):
    read_data = instr.read()
    print(str(read_data))
    return read_data

def RTMQUERYSCPI(SCPI_string, instr):
    read_data = instr.query(SCPI_string)
    print(read_data)
    return read_data

# Direct setting commands
def RTMCHANSTAT(arguments,instr):
    # arguments: [channel, status]
    
    allowed_args = ("ON","OFF")
    if arguments[1] in allowed_args:
        # build command
        SCPI_string = "CHAN"+str(arguments[0])+":STAT "+arguments[1]
        RTMWRITESCPI(SCPI_string,instr)
    else:
        print("Invalid command argument")
    
def RTMCHANOFFSET(arguments,instr):
    # arguments: [channel, offset]
    
    allowed_channels = ["1","2","3","4"]
    
    # Check whether arguments correct
    correct_arg = False
    try:
        float(arguments[1])
        if arguments[0] in allowed_channels:
            correct_arg = True
    except ValueError:
        print("Invalid command argument")
    
    if correct_arg:
        # build command
        SCPI_string = "CHAN"+str(arguments[0])+":OFFS "+arguments[1]
        RTMWRITESCPI(SCPI_string,instr)

def RTMCHANSCALE(arguments,instr):
    # arguments: [channel, scale]
    
    allowed_channels = ["1","2","3","4"]
       
    # Check whether arguments correct
    correct_arg = False
    try:
        float(arguments[1])
        if arguments[0] in allowed_channels:
            correct_arg = True
    except ValueError:
        print("Invalid command argument")
    
    if correct_arg:
        # build command
        SCPI_string = "CHAN"+str(arguments[0])+":SCAL "+arguments[1]
        RTMWRITESCPI(SCPI_string,instr)
    
def RTMTIMEOFFSET(argument,instr):
    # argument: offset

    correct_arg = False
    try:
        float(arguments)
        correct_arg = True
    except ValueError:
        print("Invalid command argument")

    if correct_arg:
        # build command
        SCPI_string = "TIM:POS "+argument
        RTMWRITESCPI(SCPI_string,instr)

def RTMTIMESCALE(argument,instr):
    # argument: scale
    
    correct_arg = False
    try:
        float(argument)
        correct_arg = True
    except ValueError:
        print("Invalid command argument")    
    
    if correct_arg:
        # build command
        SCPI_string = "TIM:SCAL "+argument
        RTMWRITESCPI(SCPI_string,instr)
    else:
        print("Invalid command argument")

def RTMDATAPOINTS(argument,instr):
    # argument: n_points
    
    correct_arg = False
    try:
        int(argument)
        correct_arg = True
    except ValueError:
        print("Invalid command argument")
        
    if correct_arg:
        # build command
        SCPI_string = "ACQ:POIN "+argument
        RTMWRITESCPI(SCPI_string,instr)

def RTMTRIGSOURCE(argument,instr):
    # argument: source channel
        
    correct_arg = False
    try:
        int(argument)
        correct_arg = True
    except ValueError:
        print("Invalid command argument")
    
    if correct_arg:
        # build command
        SCPI_string = "TRIG:A:SOUR "+argument
        RTMWRITESCPI(SCPI_string,instr)

def RTMTRIGMODE(argument,settings,instr):
    # argument: trigger mode
    
    allowed_args = ["AUTO", "NORM"]
    correct_arg = False
    try:
        if argument in allowed:args:
            correct_arg = True
    except ValueError:
        print("Invalid command argument")
    
    if correct_arg:
        # build command
        SCPI_string = "TRIG:A:MODE "+argument
        RTMWRITESCPI(SCPI_string,instr)

def RTMTRIGLEVEL(argument,settings,instr):
    # argument: trigger mode

    correct_arg = False
    try:
        float(argument)
        correct_arg = True
    except ValueError:
        print("Invalid command argument")
    
    if correct_arg:
        # build command
        SCPI_string = "TRIG:A:LEV "+argument
        RTMWRITESCPI(SCPI_string,instr)
        

# Main measurement routine
def RTMMEASURE(nWaveforms,settings,instr):
    rootfolder = settings["FILE"]["ROOTFOLDER"]
    measfolder = "/"+settings["FILE"]["MEASFOLDER"]
    
    # Set up measurement folder by date
    date = date.today()
    datestring = date.strftime("%Y-%m-%d")
    measfolder =  datestring + measfolder
    
    folder = rootfolder +"/"+ measfolder
    # Create folder
    CheckFolder(folder)
    
    # Setup measurement dictionary
    data = {                                                                        \
            "metadata": {                                                           \
                "measurement": settings["FILE"]["MEASUREMENT"],                     \
                "N": nWaveforms,                                                    \
                "Trigger channel": settings["RTM"]["TRIG_SETTINGS"]["SOUR"]         \
                "STAT": [settings["CHAN1"]["STAT"], settings["CHAN2"]["STAT"],      \
                         settings["CHAN3"]["STAT"], settings["CHAN4"]["STAT"]]      \
                        },                                                          \
            "time": {                                                               \
                "unit": "s",                                                        \
                "data": []                                                          \
                    },                                                              \
            "Channels": {                                                           \
                    "CH1":  {                                                       \
                        "unit": "V",                                                \
                        "Voltage": []                                               \
                            },                                                      \
                    "CH2":  {                                                       \
                        "unit": "V",                                                \
                        "Voltage": []                                               \
                            },                                                      \
                    "CH3":  {                                                       \
                        "unit": "V",                                                \
                        "Voltage": []                                               \
                            },                                                      \
                    "CH4":  {                                                       \
                        "unit": "V",                                                \
                        "Voltage": []                                               \
                            }                                                       \
                        }                                                           \
            }
    
    header = RTMGETHEADER(instr)
    
    for i in range(nWaveforms):
        # Build filepath according to settings, index by measurement number
        filename = settings["FILE"]["FILENAME"]+"_"+str(i+1).zfill(len(str(nWaveforms)))+".json"
        filepath = folder+"/"+filename
        data = RTMGETWAVEFORM


# Data decoder for RTM oscilloscope
def RTMDECODEWAVEFORMS(rawdata,header):
    # By default, data is read in binary packed format, this function decodes that into human-readable data.
    # [t_start, t_stop, n_samples, values per interval]
    global header
    t_start, t_stop, nSamples = header[0], header[1], header[2]
    dt=(t_stop-t_start)/(nSamples-1)
    
    # Initializing data array
    decWaves = np.zeros((1+len(rawdata),nSamples),'f')
    decWaves[0] = [round((t_start+i*dt)*1e10)/1e10 for i in range(nSamples)]
    
    for ch in range(len(rawdata)):
        # First character should be "#".
        pound = rawdata[ch][0:1]
        if pound != b'#':
            print("ERROR: Unknown data format returned from scope!")
            quit()
            
        # Second character is number of following digits for data string length value.
        length_digits = int(rawdata[ch][1:2])
        data_length = int(rawdata[ch][2:length_digits+2])
        
        # from the given data length, and known header length, we get indices:
        data_begin = length_digits + 2  # 2 for the '#' and digit count
        data_end = data_begin + data_length
        data_entries = data_length // 4;
        
        # Check that data length matches up
        if data_entries != nSamples:
            print("ERROR: Data length not consistent with number of sampleFs!")
            quit()
        # Unpack the data
        decWaves[ch+1] = np.float32(struct.unpack('f'*data_entries,rawdata[ch][data_begin:data_end]))
    return list(decWaves)
    
def RTMGETWAVEFORM(data,settings,instr):
    global OldWaveform
    global ComparisonChannel
    global CHANMEAS
    
    # As comparison channel, choose first online channel
    ChanStat = data["metadata"]["STAT"]
    for index in len(range(ChanStat)):
        if ChanStat[index] == "ON":
            ComparisonChannel = index+1
    
    
    # Check which channels are online for measurement
    for i in range(len(CHANMEAS)):
        STAT = int(RTM.query("CHAN"+str(i+1)+":STAT?"))
        if i+1==ComparisonChannel and STAT==0:
            sys.exit("ERROR: Comparison channel offline, quitting program")
        if STAT == 1:
            CHANMEAS[i] = True
        else:
            CHANMEAS[i] = False
    while True:
        # Initialize data array
        data=[]
        # Datakey tells which channels were recorded
        datakey=[]
        # Read all data channels
        if CHANMEAS[0]:
            RTM.write("CHAN1:DATA?")
            ch1 = RTM.read_raw()
            data.append(ch1)
            datakey.append("CHAN1")
        if CHANMEAS[1]:
            RTM.write("CHAN2:DATA?")
            ch2 = RTM.read_raw()
            data.append(ch2)
            datakey.append("CHAN2")
        if CHANMEAS[2]:
            RTM.write("CHAN3:DATA?")
            ch3 = RTM.read_raw()
            data.append(ch3)
            datakey.append("CHAN3")
        if CHANMEAS[3]:
            RTM.write("CHAN4:DATA?")
            ch4 = RTM.read_raw()
            data.append(ch4)
            datakey.append("CHAN4") 
        
        # Read the comparison data
        RTM.write("CHAN"+str(ComparisonChannel)+":DATA?")
        ch_check = RTM.read_raw()
        
        # Check that data has changed from last measurement (OldWaveform) 
        # and that oscilloscope didn't refresh mid-measurement (ch_check)
        if (data[ComparisonChannel-1] != OldWaveform) and (data[ComparisonChannel-1] == ch_check):
            OldWaveform = ch_check
            return data, datakey
    
    
    
    
    
    
    
    
    